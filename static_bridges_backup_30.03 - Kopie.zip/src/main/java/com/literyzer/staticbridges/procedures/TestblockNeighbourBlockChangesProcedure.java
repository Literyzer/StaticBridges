package com.literyzer.staticbridges.procedures;

import net.minecraft.world.IWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.block.Blocks;

import java.util.Map;

import com.literyzer.staticbridges.block.TestblockBlock;
import com.literyzer.staticbridges.StaticbridgesModVariables;
import com.literyzer.staticbridges.StaticbridgesMod;

public class TestblockNeighbourBlockChangesProcedure {

	public static void executeProcedure(Map<String, Object> dependencies) {
		if (dependencies.get("world") == null) {
			if (!dependencies.containsKey("world"))
				StaticbridgesMod.LOGGER.warn("Failed to load dependency world for procedure TestblockNeighbourBlockChanges!");
			return;
		}
		if (dependencies.get("x") == null) {
			if (!dependencies.containsKey("x"))
				StaticbridgesMod.LOGGER.warn("Failed to load dependency x for procedure TestblockNeighbourBlockChanges!");
			return;
		}
		if (dependencies.get("y") == null) {
			if (!dependencies.containsKey("y"))
				StaticbridgesMod.LOGGER.warn("Failed to load dependency y for procedure TestblockNeighbourBlockChanges!");
			return;
		}
		if (dependencies.get("z") == null) {
			if (!dependencies.containsKey("z"))
				StaticbridgesMod.LOGGER.warn("Failed to load dependency z for procedure TestblockNeighbourBlockChanges!");
			return;
		}
		IWorld world = (IWorld) dependencies.get("world");
		double x = dependencies.get("x") instanceof Integer ? (int) dependencies.get("x") : (double) dependencies.get("x");
		double y = dependencies.get("y") instanceof Integer ? (int) dependencies.get("y") : (double) dependencies.get("y");
		double z = dependencies.get("z") instanceof Integer ? (int) dependencies.get("z") : (double) dependencies.get("z");
		boolean found = false;
		double sx = 0;
		double sy = 0;
		double sz = 0;
		double amount = 0;
		amount = 0;
		sx = (-1);
		found = (false);
		for (int index0 = 0; index0 < (int) (3); index0++) {
			sy = (-1);
			for (int index1 = 0; index1 < (int) (3); index1++) {
				sz = (-1);
				for (int index2 = 0; index2 < (int) (3); index2++) {
					if ((world.getBlockState(new BlockPos((int) (x + sx), (int) (y + sy), (int) (z + sz)))).getBlock() == Blocks.GRANITE) {
						found = (true);
					}
					sz = (sz + 1);
				}
				sy = (sy + 1);
			}
			sx = (sx + 1);
		}
		if (found == true && StaticbridgesModVariables.MapVariables.get(world).testblock_addweight == true) {
			StaticbridgesModVariables.MapVariables
					.get(world).current_stability_testblock = (StaticbridgesModVariables.MapVariables.get(world).current_stability_testblock + 50);
			StaticbridgesModVariables.MapVariables.get(world).syncData(world);
			StaticbridgesModVariables.MapVariables.get(world).testblock_addweight = (false);
			StaticbridgesModVariables.MapVariables.get(world).syncData(world);
			if (StaticbridgesModVariables.MapVariables.get(world).current_stability_testblock >= 100) {
				if ((world.getBlockState(new BlockPos((int) x, (int) y, (int) z))).getBlock() == TestblockBlock.block) {
					world.destroyBlock(new BlockPos((int) x, (int) y, (int) z), false);
					StaticbridgesModVariables.MapVariables.get(world).testblock_addweight = (true);
					StaticbridgesModVariables.MapVariables.get(world).syncData(world);
				}
			}
		}
	}
}
